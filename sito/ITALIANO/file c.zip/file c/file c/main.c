//prova di programma definitivo
//inclusione librerie e definizione costanti
#include <stdio.h>
#define MAXRECORD 9000 //massimo numero accettabile record (3 mesi)
#define MAXSTAT 93 //massimo numero accettabile per statistiche (3 mesi)
#define MAXCOL 3 //massimo numero colonne (parametri e sensori)
#define MAXGIORNO 24 //massimo numero record per giorno
int main() {
	//definizione variabili
	FILE * fp; //puntatore per file di I/O
	int i, j, contgiorni, x=0, k; //contatori per cicli
	int dim, dimgiorno=0, dimstat=0, dim_temp=0, dim_um=0; //dimensioni effettive
	float dati[MAXRECORD][MAXCOL]; //matrice per tutti i dati
	float giorni[MAXSTAT]; //array con le date
	float giorno[MAXGIORNO][MAXCOL]; //matrice per un giorno
	float media_temp[MAXSTAT]; //array per medie temperature
	float media_um[MAXSTAT]; //array medie umidita'
	float mediana_temp[MAXSTAT]; //array mediane temperature
	float mediana_um[MAXSTAT]; //array mediane umidità
	float moda_temp[MAXSTAT]; //array mode temperatura
	float moda_um[MAXSTAT]; //array mode umidità
	float val_temp[MAXRECORD]; //array valori unici temperatura per moda
	int freq_temp[MAXRECORD]; //array frequenze temperatura per moda
	float val_um[MAXRECORD]; //array valori unici umidità per moda
	int freq_um[MAXRECORD]; //array frequenze umidità per moda
	float tmp, temp_arr[MAXSTAT]; //variabili temporanee
	int index_temp, index_um; //variabili con indici valore massimo per moda
	int cg1, cg2; //variabili con valori centrali per mediana
	int esiste_temp=-1, esiste_um=-1; //variabili per capire se il valore esiste o no
	float max_temp, max_um; //variabili per massimo valore per calcolo moda
	char path[256]; //percorso ��files per I/O
	//apertura file
	printf("Inserire il percorso del file:\n");
	scanf("%s", path);
	fp=fopen(path, "r");
	//controllo se il file esiste
	if (fp==NULL)
		printf("Errore: Il file non esiste.\n");
	else {
		//caricamento array da file
		while (fscanf(fp, "%f %f %f", &dati[i][0], &dati[i][1], &dati[i][2])!=EOF) {
			i++;
			dim++;
		}
		//caricamento array date
		for (i=0; i<dim; i++) {
			if (dimstat==0) {
				giorni[0]=dati[0][0];
				dimstat++;
			}
			else if (dati[i][0]!=giorni[dimstat-1]) {
				giorni[dimstat]=dati[i][0];
				dimstat++;
			}
		}
		//reset contatori medie
		for (i=0; i<dimstat; i++) {
				media_temp[i]=0;
				media_um[i]=0;
		}
		//ciclo principale per i giorni
		for (contgiorni=0; contgiorni<dimstat; contgiorni++) {
			dimgiorno=0;
			while (dati[x][0]==giorni[contgiorni]) {
				for (j=1; j<MAXCOL; j++)
					giorno[dimgiorno][j-1]=dati[x][j];
				//somma - primo passaggio per media
				media_temp[contgiorni]+=giorno[dimgiorno][0];
				media_um[contgiorni]+=giorno[dimgiorno][1];
				//controllo valori - primo passaggio per moda
				//temperatura
				esiste_temp=0;
				for (i=0; i<dim_temp; i++) {
					if (giorno[dimgiorno][0]==val_temp[i]) {
						esiste_temp=i;
					}
				}
				if (esiste_temp==0) {
					val_temp[dim_temp]=giorno[dimgiorno][0];
					freq_temp[dim_temp]=1;
					dim_temp++;
				}
				else {
					freq_temp[esiste_temp]++;
				}
				//umidità
				esiste_um=0;
				for (i=0; i<dim_um; i++) {
					if (giorno[dimgiorno][1]==val_um[i]) {
						esiste_um=i;
					}
				}
				if (esiste_um==0) {
					val_um[dim_um]=giorno[dimgiorno][1];
					freq_um[dim_um]=1;
					dim_um++;
				}
				else {
					freq_um[esiste_um]++;
				}
				//aumento contatori e dimensione giorno
				x++;
				dimgiorno++;
			}
			//calcolo statistiche
			//divisione - secondo passaggio per media
			media_temp[contgiorni]/=dimgiorno;
			media_um[contgiorni]/=dimgiorno;
				//copia colonna temperatura in array temporaneo
				for (i=0; i<dimgiorno; i++)
					temp_arr[i]=giorno[i][0];
				//ordinamento dell'array appena copiato
				for(i=0; i<dimgiorno-1; i++) {
					for(j=i; j<dimgiorno; j++) {
						if(temp_arr[j]<temp_arr[i]) {
							tmp=temp_arr[i];
							temp_arr[i]=temp_arr[j];
							temp_arr[j]=tmp;
						}
					}
				}
				//calcolo mediana temperatura
				if (dimgiorno%2==0) {
					cg1=dimgiorno/2-1;
					cg2=cg1+1;
					mediana_temp[contgiorni]=(temp_arr[cg1]+temp_arr[cg2])/2;
				}
				else {
					cg1=dimgiorno/2;
					mediana_temp[contgiorni]=temp_arr[cg1];
				}
				//copia colonna umidità in array temporaneo
				for (i=0; i<dimgiorno; i++)
					temp_arr[i]=giorno[i][1];
				//ordinamento dell'array appena copiato
				for(i=0; i<dimgiorno-1; i++) {
					for(j=i; j<dimgiorno; j++) {
						if(temp_arr[j]<temp_arr[i]) {
							tmp=temp_arr[i];
							temp_arr[i]=temp_arr[j];
							temp_arr[j]=tmp;
						}
					}
				}
				//calcolo mediana umidità
				if (dimgiorno%2==0) {
					cg1=dimgiorno/2-1;
					cg2=cg1+1;
					mediana_um[contgiorni]=(temp_arr[cg1]+temp_arr[cg2])/2;
				}
				else {
					cg1=dimgiorno/2;
					mediana_um[contgiorni]=temp_arr[cg1];
				}
				//calcolo moda temperatura
				max_temp=freq_temp[0];
				for (i=1; i<dim_temp; i++) {
					if (max_temp<freq_temp[i]) {
						max_temp=freq_temp[i];
						index_temp=i;
					}
				}
				moda_temp[contgiorni]=val_temp[index_temp];
				//calcolo moda umidità
				max_um=freq_um[0];
				for (i=1; i<dim_um; i++) {
					if (max_um<freq_um[i]) {
						max_um=freq_um[i];
						index_um=i;
					}
				}	
				moda_um[contgiorni]=val_um[index_um];
		}
		//esportazione array statistiche in file json
		//apertura file
		printf("Dove vuoi salvare il file?\n");
		scanf("%s", path);
		fp=fopen(path, "w");
		//esportazione array medie temperatura
		fprintf(fp, "media_temp='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", media_temp[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'\n", media_temp[i]);
		//esportazione array medie umidita'
		fprintf(fp, "media_um='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", media_um[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'\n", media_um[i]);
		//esportazione array mediane temperatura
		fprintf(fp, "mediana_temp='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", mediana_temp[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'\n", mediana_temp[i]);
		//esportazione array mediane umidita'
		fprintf(fp, "mediana_um='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", mediana_um[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'\n", mediana_um[i]);
		//esportazione array mode temperatura
		fprintf(fp, "moda_temp='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", moda_temp[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'\n", moda_temp[i]);
		//esportazione array mode umidita'
		fprintf(fp, "moda_um='[");
		for (i=0; i<dimstat-1; i++) {
			fprintf(fp, "{\"valore\": %.2f}, ", moda_um[i]);
		}
		fprintf(fp, "{\"valore\": %.2f}]'", moda_um[i]);
		printf("Esportazione completata.");
	}
	return 0;
}
